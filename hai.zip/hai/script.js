function calculateTip() {
    // Lấy giá trị từ ô nhập liệu
    const billAmount = parseFloat(document.getElementById('billAmount').value);
    const tipPercentage = parseFloat(document.getElementById('tipPercentage').value);
  
    // Kiểm tra đầu vào hợp lệ
    if (isNaN(billAmount)) {
      alert("Vui lòng nhập số tiền hóa đơn hợp lệ.");
      return;
    }
    if (isNaN(tipPercentage)) {
      alert("Vui lòng nhập phần trăm tiền boa hợp lệ.");
      return;
    }
  
    // Tính toán tiền boa và tổng số tiền
    const tipAmount = (billAmount * tipPercentage) / 100;
    const totalAmount = billAmount + tipAmount;
  
    // Hiển thị kết quả
    document.getElementById('tipAmount').textContent = tipAmount.toFixed(2);
    document.getElementById('totalAmount').textContent = totalAmount.toFixed(2);
  }